const db = require("../database");
const { startSaving, stopSaving } = require("../logger");

// 🚀 Fetch Logging Status
exports.getLoggingStatus = (req, res) => {
    const status = global.loggingActive
        ? `✅ Values are saved in Excel file with ${global.loggingInterval} sec interval`
        : "🛑 Data logging stopped";
    res.json({ status });
};

// 🚀 Fetch Backend Messages (Last 5 Logs)
exports.getBackendMessages = (req, res) => {
    const logs = global.backendLogs || [];
    res.json({ messages: logs.slice(-5) });
};

// 🚀 Fetch Dashboard Data (All Motors)
exports.getDashboardData = (req, res) => {
    db.all("SELECT * FROM motors", [], (err, rows) => {
        if (err) {
            console.error("❌ Error fetching dashboard data:", err);
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
};

// 🚀 Start/Stop Saving Data to Excel
exports.saveExcelData = (req, res) => {
    const { save, interval, folderPath } = req.body;

    if (!folderPath || typeof folderPath !== "string" || folderPath.trim() === "") {
        return res.status(400).json({ error: "❌ Folder path is required" });
    }

    const intervalMs = convertIntervalToMs(interval);

    if (save) {
        try {
            startSaving(req.user?.id || "global", intervalMs, folderPath);
            res.json({ message: `✅ Saving started every ${interval} in ${folderPath}` });
        } catch (err) {
            console.error("❌ Error starting logging:", err);
            res.status(500).json({ error: "Failed to start logging" });
        }
    } else {
        try {
            stopSaving(req.user?.id || "global");
            res.json({ message: "🛑 Saving stopped" });
        } catch (err) {
            console.error("❌ Error stopping logging:", err);
            res.status(500).json({ error: "Failed to stop logging" });
        }
    }
};

// 🚀 Convert Interval (String) to Milliseconds
const convertIntervalToMs = (interval) => {
    const timeMap = {
        "1 second": 1000,
        "10 seconds": 10000,
        "30 seconds": 30000,
        "1 minute": 60000,
        "10 minutes": 600000,
        "30 minutes": 1800000,
        "1 hour": 3600000,
        "2 hours": 7200000,
        "5 hours": 18000000,
        "10 hours": 36000000,
        "1 day": 86400000,
        "2 days": 172800000,
        "10 days": 864000000,
        "15 days": 1296000000,
        "30 days": 2592000000,
    };
    return timeMap[interval] || 10000; // Default: 10 seconds
};

const db = require("../database");

// 🚀 Fetch All Motors (Fix for Logger.js)
exports.getAllMotors = (callback) => {
    db.all("SELECT * FROM motors", [], (err, rows) => {
        if (err) return callback(err, null);
        callback(null, rows);
    });
};

// 🚀 Fetch Motors for API (Dashboard & Edit Page)
exports.getAllMotorsForAPI = (req, res) => {
    db.all("SELECT * FROM motors", [], (err, rows) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Internal Server Error", error: err.message });
        }
        res.json(rows);
    });
};

// 🚀 Fetch Motors for Set Limits Page
exports.getMotorsForSetLimits = (req, res) => {
    db.all("SELECT id, section, name, temperature_limit FROM motors", [], (err, rows) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Internal Server Error", error: err.message });
        }
        res.json(rows);
    });
};

// 🚀 Update Motor Temperature Limits
exports.updateLimit = (req, res) => {
    const { motorId, newLimit } = req.body;

    if (!motorId || !newLimit) {
        return res.status(400).json({ error: "Motor ID and new limit are required" });
    }

    db.run("UPDATE motors SET temperature_limit = ? WHERE id = ?", [newLimit, motorId], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: `Motor limit updated to ${newLimit}°C` });
    });
};

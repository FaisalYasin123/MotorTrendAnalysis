const fs = require("fs");
const csvParser = require("csv-parser");
const path = require("path");

// 🚀 Get Trend Data for Selected Motors
exports.getTrendData = (req, res) => {
  const { section, motor, startDate, endDate, frequency } = req.query;
  const folderPath = "./logs";
  let trendData = [];

  // Convert frequency to seconds
  const frequencyMap = {
    seconds: 1,
    minutes: 60,
    hours: 3600,
    days: 86400,
  };
  const freqSeconds = frequencyMap[frequency] || 60; // Default to 1 minute

  const start = new Date(startDate);
  const end = new Date(endDate);
  let currentDate = new Date(start);

  while (currentDate <= end) {
    const fileName = path.join(folderPath, `${currentDate.toISOString().split("T")[0]}.csv`);

    if (fs.existsSync(fileName)) {
      const fileData = [];
      fs.createReadStream(fileName)
        .pipe(csvParser())
        .on("data", (row) => {
          if (row.section === section && row.motor === motor) {
            fileData.push({
              timestamp: new Date(row.timestamp),
              temperature: parseFloat(row.temperature),
            });
          }
        })
        .on("end", () => {
          // Group data based on frequency
          const groupedData = [];
          let lastTimestamp = start;
          let tempSum = 0;
          let count = 0;

          fileData.forEach((entry) => {
            const timeDiff = (entry.timestamp - lastTimestamp) / 1000;
            if (timeDiff >= freqSeconds) {
              groupedData.push({
                timestamp: lastTimestamp.toISOString(),
                temperature: tempSum / (count || 1),
              });
              lastTimestamp = entry.timestamp;
              tempSum = 0;
              count = 0;
            }
            tempSum += entry.temperature;
            count++;
          });

          trendData = [...trendData, ...groupedData];

          // Send final response after last file
          if (currentDate.toISOString().split("T")[0] === endDate) {
            res.json(trendData);
          }
        });
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }
};

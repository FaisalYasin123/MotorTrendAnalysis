const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const DB_PATH = path.join(__dirname, "database.db"); // ✅ Ensure correct path

// ✅ Create a Single Shared Database Connection
const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        console.error("❌ Database connection error:", err);
        process.exit(1);
    } else {
        console.log("✅ Connected to SQLite database");
    }
});

module.exports = db; // ✅ Export database connection

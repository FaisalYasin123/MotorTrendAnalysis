INSERT INTO motors (section, name, temperature_limit) VALUES 
('Section 1', 'Motor1', 64),
('Section 1', 'Motor2', 87),
('Section 2', 'Motor3', 55),
('Section 2', 'Motor4', 95),
('Section 3', 'Motor5', 100),
('Section 3', 'Motor6', 45);

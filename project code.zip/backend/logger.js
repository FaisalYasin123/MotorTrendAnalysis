const fs = require("fs").promises;
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const { getAllMotors } = require("./models/motorModel");
const { promisify } = require("util");
const xlsx = require("xlsx");
const pathIsInside = require("path-is-inside");

// Constants
const SHEET_NAME = "Temperature Data";
const MAX_RETRIES = 5;
const RETRY_DELAY = 5000;
const COLUMN_HEADERS = ["Serial No", "Time", "Motor ID", "Section Name", "Motor Name", "Temperature"];

// Database setup
const db = new sqlite3.Database("./database.db");
const dbRun = promisify(db.run).bind(db);
const dbGet = promisify(db.get).bind(db);
const dbAll = promisify(db.all).bind(db);

// State management
const state = {
    activeSessions: new Map(),
    backendLogs: [],
    MAX_LOG_ENTRIES: 200
};

// Initialize database schema
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS logging_state (
        userId TEXT PRIMARY KEY,
        interval INTEGER,
        folderPath TEXT,
        lastWrite INTEGER,
        isActive INTEGER DEFAULT 0
    )`);
});

class LoggingSession {
    constructor(userId, interval, folderPath) {
        this.userId = userId;
        this.interval = interval;
        this.folderPath = folderPath;
        this.isActive = false;
        this.intervalId = null;
        this.retryCount = 0;
        this.lastWrite = null;
    }

    async writeData() {
        try {
            console.log(`🔹 Fetching motor data for user: ${this.userId}`);
            const motors = await getAllMotors();
            
            if (!motors?.length) {
                console.warn(`⚠️ No motor data available for user: ${this.userId}`);
                return;
            }

            const dateString = new Date().toISOString().split('T')[0];
            const filePath = path.join(this.folderPath, `Equipment_Temperature_${dateString}.xlsx`);
            
            let workbook, worksheet;
            try {
                workbook = xlsx.readFile(filePath);
                worksheet = workbook.Sheets[SHEET_NAME];
                
                // Create sheet if it doesn't exist in existing workbook
                if (!worksheet) {
                    worksheet = xlsx.utils.aoa_to_sheet([COLUMN_HEADERS]);
                    xlsx.utils.book_append_sheet(workbook, worksheet, SHEET_NAME);
                }
            } catch (error) {
                // Create new workbook if file doesn't exist
                workbook = xlsx.utils.book_new();
                worksheet = xlsx.utils.aoa_to_sheet([COLUMN_HEADERS]);
                xlsx.utils.book_append_sheet(workbook, worksheet, SHEET_NAME);
            }

            const serialNo = worksheet['!ref'] ? xlsx.utils.decode_range(worksheet['!ref']).e.r + 1 : 1;
            const timeStamp = new Date().toLocaleTimeString();

            xlsx.utils.sheet_add_aoa(worksheet, motors.map((motor, i) => [
                serialNo + i,
                timeStamp,
                motor.id,
                motor.section,
                motor.name,
                motor.temperature
            ]), { origin: -1 });

            await this.safeFileWrite(filePath, workbook);
            this.retryCount = 0;
            this.lastWrite = Date.now();
            
            await dbRun(
                `UPDATE logging_state SET lastWrite = ? WHERE userId = ?`,
                [this.lastWrite, this.userId]
            );

            console.log(`✅ Data written successfully for user: ${this.userId}`);

        } catch (error) {
            this.handleWriteError(error);
        }
    }

    async safeFileWrite(filePath, workbook) {
        for (let i = 0; i < MAX_RETRIES; i++) {
            try {
                return await fs.writeFile(filePath, xlsx.write(workbook, { type: "buffer" }));
            } catch (error) {
                if (['EBUSY', 'EACCES'].includes(error.code)) {
                    console.warn(`⏳ File locked, retrying... (${i + 1}/${MAX_RETRIES})`);
                    await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
                    continue;
                }
                throw error;
            }
        }
        throw new Error(`File write failed after ${MAX_RETRIES} attempts`);
    }

    handleWriteError(error) {
        console.error(`❌ Write error: ${error.message}`);
        
        // Manage log entries
        state.backendLogs.push(`Write error: ${error.message}`);
        if (state.backendLogs.length > state.MAX_LOG_ENTRIES) {
            state.backendLogs.shift();
        }

        if (++this.retryCount > MAX_RETRIES) this.stop();
    }

    start() {
        if (this.isActive) return;
        this.isActive = true;
        console.log(`🚀 Starting logging session for user: ${this.userId}`);
        
        // Handle interval writes with error catching
        this.intervalId = setInterval(async () => {
            try {
                await this.writeData();
            } catch (error) {
                console.error(`Interval write error: ${error.message}`);
                this.handleWriteError(error);
            }
        }, this.interval * 1000);
        
        // Initial write with error catching
        (async () => {
            try {
                await this.writeData();
            } catch (error) {
                console.error(`Initial write error: ${error.message}`);
                this.handleWriteError(error);
            }
        })();
    }

    stop() {
        clearInterval(this.intervalId);
        this.isActive = false;
        console.log(`🛑 Stopping logging session for user: ${this.userId}`);
        state.activeSessions.delete(this.userId);
    }
}

// Enhanced path validation
const validatePath = (folderPath) => {
    const resolved = path.resolve(folderPath);
    
    if (!pathIsInside(resolved, process.cwd())) {
        throw new Error('Invalid file path');
    }
    
    return resolved;
};

const startSaving = async (userId, interval, folderPath) => {
    try {
        console.log(`🔍 Validating path for user: ${userId}`);
        const safePath = validatePath(folderPath);
        await fs.mkdir(safePath, { recursive: true });

        if (state.activeSessions.has(userId)) {
            console.log(`🔄 Restarting session for user: ${userId}`);
            state.activeSessions.get(userId).stop();
        }

        const session = new LoggingSession(userId, interval, safePath);
        session.start();
        state.activeSessions.set(userId, session);

        await dbRun(
            `INSERT OR REPLACE INTO logging_state VALUES (?, ?, ?, ?, ?)`,
            [userId, interval, safePath, Date.now(), 1]
        );

        console.log(`✅ Logging started successfully for user: ${userId}`);
        return true;
    } catch (error) {
        console.error("❌ ERROR: Failed to start logging:", error);
        state.backendLogs.push(`Start failed: ${error.message}`);
        throw error;
    }
};

const stopSaving = async (userId) => {
    if (!state.activeSessions.has(userId)) return false;
    
    try {
        await dbRun(
            `UPDATE logging_state SET isActive = 0 WHERE userId = ?`,
            [userId]
        );
        
        state.activeSessions.get(userId).stop();
        return true;
    } catch (error) {
        console.error("Failed to update database on stop:", error);
        return false;
    }
};

// Initialize active sessions with database state
const initializeSessions = async () => {
    try {
        console.log("🔄 Restoring active sessions...");
        const rows = await dbAll("SELECT * FROM logging_state WHERE isActive = 1");
        
        for (const row of rows) {
            const session = new LoggingSession(
                row.userId,
                row.interval,
                row.folderPath
            );
            session.lastWrite = row.lastWrite;
            session.start();
            state.activeSessions.set(row.userId, session);
        }
        
        console.log("✅ Active sessions restored.");
    } catch (error) {
        console.error("❌ ERROR: Failed to initialize sessions:", error);
    }
};

// Session timeout handling
setInterval(() => {
    const now = Date.now();
    state.activeSessions.forEach((session) => {
        if (session.lastWrite && (now - session.lastWrite) > session.interval * 2 * 1000) {
            console.warn(`⚠️ Session timeout detected for user: ${session.userId}`);
            session.stop();
        }
    });
}, 10000);

// Clean shutdown handling
process.on("SIGINT", async () => {
    console.log("🛑 Shutting down, stopping all sessions...");
    await Promise.all([...state.activeSessions.values()].map(session => stopSaving(session.userId)));
    db.close();
    process.exit();
});

module.exports = {
    startSaving,
    stopSaving,
    getLogs: () => state.backendLogs,
    getActiveSessions: () => state.activeSessions,
    initializeSessions
};
const db = require("../database"); // ✅ Import shared database connection

// 🚀 Get All Motors
exports.getAllMotors = async () => {
    return new Promise((resolve, reject) => {
        db.all("SELECT * FROM motors", [], (err, rows) => {
            if (err) reject(err);
            else resolve(rows || []); // ✅ Always return an array
        });
    });
};

// 🚀 Get Motors by Section
exports.getMotorsBySection = async (section) => {
    return new Promise((resolve, reject) => {
        db.all("SELECT * FROM motors WHERE section = ?", [section], (err, rows) => {
            if (err) reject(err);
            else resolve(rows || []);
        });
    });
};

// 🚀 Add a New Motor
exports.addMotor = async (section, motorName, limit) => {
    return new Promise((resolve, reject) => {
        db.run(
            "INSERT INTO motors (section, name, limit) VALUES (?, ?, ?)",
            [section, motorName, limit],
            function (err) {
                if (err) reject(err);
                else resolve({ id: this.lastID, section, motorName, limit });
            }
        );
    });
};

// 🚀 Update Motor Name
exports.updateMotorName = async (motorId, newName) => {
    return new Promise((resolve, reject) => {
        db.run("UPDATE motors SET name = ? WHERE id = ?", [newName, motorId], (err) => {
            if (err) reject(err);
            else resolve({ id: motorId, name: newName });
        });
    });
};

// 🚀 Update Motor Temperature Limit
exports.updateMotorLimit = async (motorId, newLimit) => {
    return new Promise((resolve, reject) => {
        db.run("UPDATE motors SET limit = ? WHERE id = ?", [newLimit, motorId], (err) => {
            if (err) reject(err);
            else resolve({ id: motorId, limit: newLimit });
        });
    });
};

// 🚀 Delete a Motor
exports.deleteMotor = async (motorId) => {
    return new Promise((resolve, reject) => {
        db.run("DELETE FROM motors WHERE id = ?", [motorId], (err) => {
            if (err) reject(err);
            else resolve({ message: `Motor ID ${motorId} deleted successfully` });
        });
    });
};

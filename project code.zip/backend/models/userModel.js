const db = require("../database");
const bcrypt = require("bcryptjs");

// 🚀 Register a New User
exports.registerUser = (username, password, callback) => {
  const hashedPassword = bcrypt.hashSync(password, 10); // Hash the password

  db.run(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    [username, hashedPassword],
    function (err) {
      if (err) return callback(err);
      callback(null, { id: this.lastID, username });
    }
  );
};

// 🚀 Find User by Username
exports.findUserByUsername = (username, callback) => {
  db.get("SELECT * FROM users WHERE username = ?", [username], (err, user) => {
    if (err) return callback(err, null);
    callback(null, user);
  });
};

// 🚀 Find User by ID
exports.findUserById = (userId, callback) => {
  db.get("SELECT * FROM users WHERE id = ?", [userId], (err, user) => {
    if (err) return callback(err, null);
    callback(null, user);
  });
};

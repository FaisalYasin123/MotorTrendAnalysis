const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();
const nodemailer = require("nodemailer");

const USERS_FILE = path.join(__dirname, "../data/users.json");

// Load User Data
function loadUsers() {
    return fs.existsSync(USERS_FILE) ? JSON.parse(fs.readFileSync(USERS_FILE, "utf8")) : {};
}

// Save User Data
function saveUsers(data) {
    fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 4));
}

// Login
router.post("/login", (req, res) => {
    const { username, password } = req.body;
    const user = loadUsers();

    if (username === user.username && password === user.password) {
        res.json({ success: true, message: "Login Successful" });
    } else {
        res.status(401).json({ success: false, message: "Invalid Credentials" });
    }
});

// Change Password
router.post("/change-password", (req, res) => {
    const { oldPassword, newPassword } = req.body;
    let user = loadUsers();

    if (oldPassword === user.password) {
        user.password = newPassword;
        saveUsers(user);
        res.json({ success: true, message: "Password changed successfully" });
    } else {
        res.status(400).json({ success: false, message: "Incorrect old password" });
    }
});

// Set Email for Password Recovery
router.post("/set-email", (req, res) => {
    const { email } = req.body;
    let user = loadUsers();
    user.email = email;
    saveUsers(user);
    res.json({ success: true, message: "Email saved successfully" });
});

// Forgot Password - Send Email
router.post("/forgot-password", (req, res) => {
    let user = loadUsers();

    if (!user.email) return res.status(400).json({ success: false, message: "No email set for recovery" });

    let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: { user: "your-email@gmail.com", pass: "your-password" }
    });

    let mailOptions = {
        from: "your-email@gmail.com",
        to: user.email,
        subject: "Password Reset",
        text: `Your password is: ${user.password}`
    };

    transporter.sendMail(mailOptions, (error) => {
        if (error) return res.status(500).json({ success: false, message: "Error sending email" });
        res.json({ success: true, message: "Password sent to email" });
    });
});

module.exports = router;

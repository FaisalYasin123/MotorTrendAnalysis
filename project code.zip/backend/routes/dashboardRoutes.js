const express = require("express");
const router = express.Router();
const dashboardController = require("../controllers/dashboardController");

// ✅ Fetch Dashboard Data (All Motors)
router.get("/", dashboardController.getDashboardData);

// ✅ Start/Stop Saving Data to Excel
router.post("/save-excel", dashboardController.saveExcelData);

// 🚀 API to Get Logging Status
router.get("/logging-status", dashboardController.getLoggingStatus);

// 🚀 API to Get Backend Messages (Last 5 Logs)
router.get("/log-messages", dashboardController.getBackendMessages);

module.exports = router;

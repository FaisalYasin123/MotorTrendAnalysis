const express = require("express");
const db = require("../database");
const router = express.Router();

// ✅ Fetch all motors
router.get("/all", (req, res) => {
  db.all("SELECT * FROM motors", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// ✅ Fetch all sections
router.get("/sections", (req, res) => {
  db.all("SELECT DISTINCT section FROM motors", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows.map((row) => row.section));
  });
});

// ✅ Edit Motor Name
router.post("/edit", (req, res) => {
  const { id, newName, type } = req.body;
  if (!id || !newName || !type) return res.status(400).json({ error: "ID, new name, and type are required" });

  if (type === "motor") {
    db.run("UPDATE motors SET name = ? WHERE id = ?", [newName, id], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Motor name updated successfully" });
    });
  } else if (type === "section") {
    db.run("UPDATE motors SET section = ? WHERE section = ?", [newName, id], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Section name updated successfully" });
    });
  } else {
    res.status(400).json({ error: "Invalid type. Must be 'motor' or 'section'" });
  }
});

// ✅ Delete Motor
router.post("/delete", (req, res) => {
  const { id } = req.body;
  if (!id) return res.status(400).json({ error: "Motor ID is required" });

  db.run("DELETE FROM motors WHERE id = ?", [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Motor deleted successfully" });
  });
});

// ✅ Add a New Motor
router.post("/add", (req, res) => {
  const { section, motorName, limit } = req.body;
  if (!section || !motorName || limit === undefined) return res.status(400).json({ error: "Section, motor name, and limit are required" });

  db.run("INSERT INTO motors (section, name, temperature_limit) VALUES (?, ?, ?)", [section, motorName, limit], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Motor added successfully" });
  });
});

// ✅ Delete Section
router.post("/delete-section", (req, res) => {
  const { section } = req.body;
  if (!section) return res.status(400).json({ error: "Section name is required" });

  db.run("DELETE FROM motors WHERE section = ?", [section], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Section and all its motors deleted successfully" });
  });
});

// ✅ Add a New Section
router.post("/add-section", (req, res) => {
  const { sectionName, motorCount } = req.body;
  if (!sectionName || motorCount < 1) return res.status(400).json({ error: "Enter a valid section name and motor count." });

  for (let i = 1; i <= motorCount; i++) {
    db.run("INSERT INTO motors (section, name, temperature_limit) VALUES (?, ?, ?)", [sectionName, `Motor${i}`, 80], (err) => {
      if (err) return res.status(500).json({ error: err.message });
    });
  }

  res.json({ message: `Section '${sectionName}' added with ${motorCount} motors!` });
});

// ✅ Update Motor Limit
router.post("/set-limit", (req, res) => {
  const { motorId, newLimit } = req.body;
  if (!motorId || newLimit === undefined) return res.status(400).json({ error: "Motor ID and new limit are required" });

  db.run("UPDATE motors SET temperature_limit = ? WHERE id = ?", [newLimit, motorId], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Motor limit updated successfully" });
  });
});

module.exports = router;
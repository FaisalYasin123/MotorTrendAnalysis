
const express = require("express");
const router = express.Router();
const trendController = require("../controllers/trendController");

// 🚀 Route: Get Trend Data for Selected Motors
router.get("/", trendController.getTrendData);

module.exports = router;

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { startSaving, stopSaving, activeSessions } = require("./logger");

// Routes
const dashboardRoutes = require("./routes/dashboardRoutes");
const motorRoutes = require("./routes/motorRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();
const PORT = process.env.PORT || 5000;
const HEARTBEAT_TIMEOUT = process.env.HEARTBEAT_TIMEOUT || 15000;

// 🛠️ Middleware
app.use(cors());
app.use(bodyParser.json());

// 🔐 Authentication Middleware (Replace with your actual implementation)
app.use((req, res, next) => {
    req.user = { 
        id: req.headers['x-user-id'] || 'default-user', 
        role: 'admin' 
    };
    next();
});

// 📊 Request Logging Middleware
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// ❤️ Heartbeat Endpoint (Prevents Session Timeout)
app.post("/api/heartbeat", (req, res) => {
    const userId = req.user.id;
    const session = activeSessions.get(userId);
    
    if (session) {
        session.lastActivity = Date.now();
        console.debug(`❤️ [${userId}] Heartbeat received`);
    }
    
    res.status(200).json({ 
        success: true, 
        timestamp: Date.now() 
    });
});

// 🎛️ Enhanced Save Excel Endpoint
app.post("/api/dashboard/save-excel", async (req, res) => {
    try {
        const userId = req.user.id;
        const { save, interval, folderPath } = req.body;

        // 🛡️ Input Validation
        if (!folderPath?.trim()) {
            return res.status(400).json({ 
                error: "Valid folder path required (e.g., C:\\MyFolder)" 
            });
        }

        if (typeof interval !== 'number' || interval < 1000 || interval > 86400000) {
            return res.status(400).json({ 
                error: "Interval must be between 1 second and 24 hours (1000-86400000 ms)" 
            });
        }

        if (save) {
            await startSaving(userId, interval, folderPath);
            console.log(`🚀 [${userId}] Started saving to: ${folderPath}`);
            return res.json({ 
                success: true,
                message: `Saving every ${interval / 1000}s to ${folderPath}`,
                folderPath
            });
        }

        await stopSaving(userId);
        console.log(`🛑 [${userId}] Stopped saving`);
        return res.json({ 
            success: true, 
            message: "Logging stopped" 
        });

    } catch (err) {
        console.error("🔥 Save Error:", err);
        res.status(500).json({ 
            success: false,
            error: process.env.NODE_ENV === 'development' 
                ? err.message 
                : "Failed to update logging state"
        });
    }
});

// 🛑 Stop Logging Endpoint
app.post("/api/stop-logging", (req, res) => {
    try {
        const userId = req.user.id;
        stopSaving(userId);
        res.json({ 
            success: true, 
            message: "Logging stopped for your session" 
        });
    } catch (err) {
        console.error("🔥 Stop Logging Error:", err);
        res.status(500).json({ 
            success: false,
            error: "Failed to stop logging" 
        });
    }
});

// 🗺️ Route Imports
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/motors", motorRoutes);
app.use("/api/auth", authRoutes);

// 🏠 Default Route
app.get("/", (req, res) => {
    res.json({
        status: "operational",
        version: "2.0.0",
        routes: {
            dashboard: "/api/dashboard",
            motors: "/api/motors",
            auth: "/api/auth"
        }
    });
});

// 🚨 Error Handling
app.use((err, req, res, next) => {
    console.error("🔥 Server Error:", {
        path: req.path,
        method: req.method,
        error: err.stack
    });
    
    res.status(500).json({
        success: false,
        message: process.env.NODE_ENV === 'production'
            ? "Internal server error"
            : err.message
    });
});

// 🚀 Start Server
app.listen(PORT, () => {
    console.log(`\n\x1b[36m
    ███╗   ███╗ ██████╗ ████████╗ ██████╗ ██████╗ 
    ████╗ ████║██╔═══██╗╚══██╔══╝██╔═══██╗██╔══██╗
    ██╔████╔██║██║   ██║   ██║   ██║   ██║██████╔╝
    ██║╚██╔╝██║██║   ██║   ██║   ██║   ██║██╔══██╗
    ██║ ╚═╝ ██║╚██████╔╝   ██║   ╚██████╔╝██║  ██║
    ╚═╝     ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚═╝  ╚═╝ v2.0\x1b[0m\n
    `);
    console.log(`🚀 Server running on port \x1b[32m${PORT}\x1b[0m`);
    console.log(`🔐 Authentication Mode: \x1b[33m${process.env.AUTH_ENABLED || 'development'}\x1b[0m`);
    console.log(`📁 Log Storage: \x1b[34m${process.env.LOG_BASE_PATH || './logs'}\x1b[0m`);
});

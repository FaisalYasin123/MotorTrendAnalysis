import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { GlobalStateProvider } from "./GlobalStateContext"; 
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import Dashboard from "./pages/Dashboard";
import EditPage from "./pages/EditPage";
import SetLimits from "./pages/SetLimits";
import TrendAnalysis from "./pages/TrendAnalysis";
import ExcelSaving from "./pages/ExcelSaving";  // ✅ Import ExcelSaving.js
import "./App.css";

function App() {
  return (
    <GlobalStateProvider>
      <Router>
        <div className="app-container">
          <Sidebar />
          <div className="main-content">
            <Navbar />
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/edit" element={<EditPage />} />
              <Route path="/set-limits" element={<SetLimits />} />
              <Route path="/trend-analysis" element={<TrendAnalysis />} />
              <Route path="/excel-saving" element={<ExcelSaving />} />  {/* ✅ Added Route for Excel Saving */}
            </Routes>
          </div>
        </div>
      </Router>
    </GlobalStateProvider>
  );
}

export default App;

import React, { createContext, useContext, useState, useEffect } from "react";

const GlobalStateContext = createContext();

export const GlobalStateProvider = ({ children }) => {
  const [isSaving, setIsSaving] = useState(() => JSON.parse(localStorage.getItem("isSaving")) || false);
  const [folderPath, setFolderPath] = useState(localStorage.getItem("folderPath") || "");
  const [saveInterval, setSaveInterval] = useState(localStorage.getItem("saveInterval") || "10 seconds");

  useEffect(() => {
    localStorage.setItem("isSaving", JSON.stringify(isSaving));
    localStorage.setItem("folderPath", folderPath);
    localStorage.setItem("saveInterval", saveInterval);
  }, [isSaving, folderPath, saveInterval]);

  return (
    <GlobalStateContext.Provider value={{ isSaving, setIsSaving, folderPath, setFolderPath, saveInterval, setSaveInterval }}>
      {children}
    </GlobalStateContext.Provider>
  );
};

export const useGlobalState = () => useContext(GlobalStateContext);

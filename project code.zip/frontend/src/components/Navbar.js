import React from "react";
import "./Navbar.css"; // Import CSS for styling

const Navbar = () => {
  return (
    <nav className="navbar">
      <h1 className="page-title">Equipment Temperature Analysis</h1>
    </nav>
  );
};

export default Navbar;

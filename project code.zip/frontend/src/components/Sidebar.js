import React from "react";
import { Link } from "react-router-dom";
import "./Sidebar.css"; // Import CSS for styling

const Sidebar = () => {
  return (
    <div className="sidebar">
      <h2 className="sidebar-title">Navigation</h2>
      <ul className="sidebar-links">
        <li><Link to="/">🏠 Dashboard</Link></li>
        <li><Link to="/edit">🛠️ Edit Motors</Link></li>
        <li><Link to="/set-limits">⚙️ Set Limits</Link></li>
        <li><Link to="/trend-analysis">📈 Trend Analysis</Link></li>
        <li><Link to="/excel-saving">📊 Excel Saving</Link></li> {/* Added the missing link */}
      </ul>
    </div>
  );
};

export default Sidebar;

import React, { useState, useEffect } from "react";
import axios from "axios";
import { useGlobalState } from "../GlobalStateContext";
import "./Dashboard.css";

const Dashboard = () => {
  const { isSaving, setIsSaving } = useGlobalState();
  const [motors, setMotors] = useState([]);
  const [sections, setSections] = useState([]);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [loggingStatus, setLoggingStatus] = useState(localStorage.getItem("loggingStatus") || "Checking logging status...");

  // ✅ Fetch Motors & Sections
  useEffect(() => {
    const fetchMotors = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/dashboard");
        setMotors(res.data);

        const uniqueSections = [...new Set(res.data.map(motor => motor.section))];
        setSections(uniqueSections);
      } catch (err) {
        console.error("Error fetching data:", err);
      }
    };

    fetchMotors();
    const interval = setInterval(fetchMotors, 10000);
    return () => clearInterval(interval);
  }, []);

  // ✅ Fetch Logging Status from API
  useEffect(() => {
    const fetchStatus = () => {
      fetch('/api/logging-status')
        .then(response => response.json())
        .then(data => {
          setLoggingStatus(data.status);
          localStorage.setItem("loggingStatus", data.status);
        })
        .catch(error => console.error('Error fetching status:', error));
    };

    fetchStatus();
    const intervalId = setInterval(fetchStatus, 5000);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="dashboard">
      <h1>🏠 Dashboard</h1>

      {/* ✅ Show Logging Status */}
      <h3>📜 Logging Status: {loggingStatus}</h3>

      {/* ✅ Display Sections & Motors */}
      <div className="section-navigation">
        <button onClick={() => setCurrentSectionIndex(prev => (prev - 1 + sections.length) % sections.length)}>⬅ Previous</button>
        <h2>{sections[currentSectionIndex] || "Loading Sections..."}</h2>
        <button onClick={() => setCurrentSectionIndex(prev => (prev + 1) % sections.length)}>Next ➡</button>
      </div>

      <div className="motor-grid">
        {motors.filter(motor => motor.section === sections[currentSectionIndex]).map(motor => (
          <div key={motor.id} className="motor-card">
            <h3>{motor.name}</h3>
            <p>🌡 Temperature: {motor.temperature}°C</p>
            <p>🚨 Limit: {motor.temperature_limit}°C</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;

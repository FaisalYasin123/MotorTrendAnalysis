import React, { useEffect, useState } from "react";
import axios from "axios";
import "./EditPage.css"; // Import styles

const EditPage = () => {
  const [motors, setMotors] = useState([]);
  const [sections, setSections] = useState([]);

  const [selectedMotorId, setSelectedMotorId] = useState("");
  const [newMotorName, setNewMotorName] = useState("");

  const [selectedSectionForMotor, setSelectedSectionForMotor] = useState("");
  const [newMotorNameForAdd, setNewMotorNameForAdd] = useState("");

  const [selectedSectionForEdit, setSelectedSectionForEdit] = useState("");
  const [newSectionName, setNewSectionName] = useState("");
  const [motorCount, setMotorCount] = useState(1);

  useEffect(() => {
    // Fetch motors and sections from the API
    axios.get("http://localhost:5000/api/motors/all")
      .then((res) => setMotors(res.data || []))
      .catch((err) => console.error("Error fetching motors:", err));

    axios.get("http://localhost:5000/api/motors/sections")
      .then((res) => setSections(res.data || []))
      .catch((err) => console.error("Error fetching sections:", err));
  }, []);

  return (
    <div className="edit-page">
      <h2>⚙️ Edit Motors & Sections</h2>

      {/* 🚀 Edit Motor Name */}
      <div className="edit-container">
        <h3>Edit Motor Name</h3>
        <select onChange={(e) => setSelectedMotorId(e.target.value)}>
          <option value="">-- Select Motor --</option>
          {motors.map((motor) => (
            <option key={motor.id} value={motor.id}>
              {motor.name} (Section: {motor.section})
            </option>
          ))}
        </select>
        <input type="text" placeholder="New Motor Name" onChange={(e) => setNewMotorName(e.target.value)} />
        <button onClick={() => axios.post("http://localhost:5000/api/motors/edit", { id: selectedMotorId, newName: newMotorName, type: "motor" })
          .then(() => { alert("Motor renamed!"); window.location.reload(); })
          .catch((err) => console.error("Error renaming motor:", err))}>
          ✏️ Rename Motor
        </button>
      </div>

      {/* 🚀 Delete Motor */}
      <div className="edit-container">
        <h3>Delete Motor</h3>
        <select onChange={(e) => setSelectedMotorId(e.target.value)}>
          <option value="">-- Select Motor --</option>
          {motors.map((motor) => (
            <option key={motor.id} value={motor.id}>
              {motor.name} (Section: {motor.section})
            </option>
          ))}
        </select>
        <button className="delete-btn" onClick={() => axios.post("http://localhost:5000/api/motors/delete", { id: selectedMotorId })
          .then(() => { alert("Motor deleted!"); window.location.reload(); })
          .catch((err) => console.error("Error deleting motor:", err))}>
          🗑️ Delete Motor
        </button>
      </div>

      {/* 🚀 Add New Motor */}
      <div className="edit-container">
        <h3>Add New Motor</h3>
        <select onChange={(e) => setSelectedSectionForMotor(e.target.value)}>
          <option value="">-- Select Section --</option>
          {sections.map((section) => (
            <option key={section} value={section}>{section}</option>
          ))}
        </select>
        <input type="text" placeholder="New Motor Name" onChange={(e) => setNewMotorNameForAdd(e.target.value)} />
        <button onClick={() => axios.post("http://localhost:5000/api/motors/add", { section: selectedSectionForMotor, motorName: newMotorNameForAdd, limit: 80 })
          .then(() => { alert("Motor added!"); window.location.reload(); })
          .catch((err) => console.error("Error adding motor:", err))}>
          ➕ Add Motor
        </button>
      </div>

      {/* 🚀 Delete Section */}
      <div className="edit-container">
        <h3>Delete Section</h3>
        <select onChange={(e) => setSelectedSectionForEdit(e.target.value)}>
          <option value="">-- Select Section --</option>
          {sections.map((section) => (
            <option key={section} value={section}>{section}</option>
          ))}
        </select>
        <button className="delete-btn" onClick={() => axios.post("http://localhost:5000/api/motors/delete-section", { section: selectedSectionForEdit })
          .then(() => { alert("Section deleted!"); window.location.reload(); })
          .catch((err) => console.error("Error deleting section:", err))}>
          🗑️ Delete Section
        </button>
      </div>

      {/* 🚀 Add New Section */}
      <div className="edit-container">
        <h3>Add New Section</h3>
        <input type="text" placeholder="New Section Name" onChange={(e) => setNewSectionName(e.target.value)} />
        <input type="number" placeholder="Number of Motors" min="1" onChange={(e) => setMotorCount(e.target.value)} />
        <button onClick={() => axios.post("http://localhost:5000/api/motors/add-section", { sectionName: newSectionName, motorCount })
          .then(() => { alert("Section added!"); window.location.reload(); })
          .catch((err) => console.error("Error adding section:", err))}>
          ➕ Add Section
        </button>
      </div>
    </div>
  );
};

export default EditPage;
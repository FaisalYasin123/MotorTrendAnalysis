import React, { useState, useEffect } from 'react';
import './ExcelSaving.css';

const ExcelSaving = () => {
    const [folderPath, setFolderPath] = useState('');
    const [loggingInterval, setLoggingInterval] = useState(10);
    const [loggingStatus, setLoggingStatus] = useState('❌ Data logging stopped');
    const [backendMessages, setBackendMessages] = useState([]);
    const [savedFolderPath, setSavedFolderPath] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);

    // Load initial state from localStorage
    useEffect(() => {
        const savedStatus = localStorage.getItem("loggingStatus");
        const savedPath = localStorage.getItem("savedFolderPath");
        if (savedStatus) setLoggingStatus(savedStatus);
        if (savedPath) setSavedFolderPath(savedPath);
    }, []);

    // Function to start data logging
    const startLogging = async () => {
        if (!folderPath.trim()) {
            alert("⚠ Please enter a valid folder path!");
            return;
        }

        setIsProcessing(true);
        try {
            const response = await fetch('/api/start-logging', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ folderPath, interval: loggingInterval })
            });

            if (!response.ok) throw new Error("Failed to start logging");

            setLoggingStatus(`✅ Values are saved every ${loggingInterval} sec`);
            setSavedFolderPath(folderPath);
            localStorage.setItem("loggingStatus", `✅ Values are saved every ${loggingInterval} sec`);
            localStorage.setItem("savedFolderPath", folderPath);
        } catch (error) {
            setLoggingStatus('❌ Error starting logging');
            alert(`Failed to start logging: ${error.message}`);
        } finally {
            setIsProcessing(false);
        }
    };

    // Function to stop data logging
    const stopLogging = async () => {
        setIsProcessing(true);
        try {
            const response = await fetch('/api/stop-logging', { method: 'POST' });
            if (!response.ok) throw new Error("Failed to stop logging");

            setLoggingStatus('❌ Data logging stopped');
            setSavedFolderPath('');
            localStorage.setItem("loggingStatus", "❌ Data logging stopped");
            localStorage.removeItem("savedFolderPath");
        } catch (error) {
            setLoggingStatus('❌ Error stopping logging');
            alert(`Failed to stop logging: ${error.message}`);
        } finally {
            setIsProcessing(false);
        }
    };

    // Fetch backend messages
    useEffect(() => {
        const fetchMessages = () => {
            fetch('/api/log-messages')
                .then(response => response.json())
                .then(data => setBackendMessages(data.messages))
                .catch(error => console.error('Error fetching messages:', error));
        };

        const intervalId = setInterval(fetchMessages, 5000);
        return () => clearInterval(intervalId);
    }, []);

    return (
        <div className="excel-saving-container">
            <h2>📊 Excel Data Logging</h2>

            {/* ✅ Folder Path Input */}
            <label>📂 Enter Folder Path:</label>
            <input 
                type="text" 
                value={folderPath} 
                onChange={(e) => setFolderPath(e.target.value)} 
                placeholder="Enter folder path where Excel will be saved..."
            />
            
            {/* ✅ Interval Selection */}
            <label>⏳ Select Logging Interval:</label>
            <select value={loggingInterval} onChange={(e) => setLoggingInterval(Number(e.target.value))}>
                <option value="1">1 second</option>
                <option value="10">10 seconds (default)</option>
                <option value="30">30 seconds</option>
                <option value="60">1 minute</option>
                <option value="300">5 minutes</option>
                <option value="1800">30 minutes</option>
                <option value="3600">1 hour</option>
                <option value="86400">1 day</option>
            </select>

            {/* ✅ Buttons */}
            <div className="button-group">
                <button onClick={startLogging} disabled={isProcessing}>▶ Start Logging</button>
                <button onClick={stopLogging} disabled={isProcessing}>⏹ Stop Logging</button>
            </div>

            {/* ✅ Logging Status */}
            <h3 className="logging-status">📜 Status: {loggingStatus}</h3>
            
            {/* ✅ Show Folder Path if Logging is Active */}
            {savedFolderPath && (
                <p className="file-path">✅ Data is being saved in folder: <strong>{savedFolderPath}</strong></p>
            )}

            {/* ✅ Backend Messages */}
            <h4>📥 Backend Messages:</h4>
            <div className="backend-messages">
                {backendMessages.length > 0 ? (
                    backendMessages.map((msg, index) => (
                        <p key={index}>{msg}</p>
                    ))
                ) : (
                    <p>No messages from backend yet.</p>
                )}
            </div>
        </div>
    );
};

export default ExcelSaving;

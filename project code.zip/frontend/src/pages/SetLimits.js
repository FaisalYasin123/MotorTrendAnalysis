import React, { useEffect, useState } from "react";
import axios from "axios";

const SetLimits = () => {
  const [motors, setMotors] = useState([]);
  const [selectedMotorId, setSelectedMotorId] = useState("");
  const [newLimit, setNewLimit] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    axios.get("http://localhost:5000/api/motors/all")
      .then((res) => setMotors(res.data || []))
      .catch((err) => console.error("Error fetching motors:", err));
  }, []);

  const handleSetLimit = () => {
    if (!selectedMotorId || !newLimit) {
      alert("⚠️ Please select a motor and enter a new limit!");
      return;
    }

    axios.post("http://localhost:5000/api/motors/set-limit", { motorId: selectedMotorId, newLimit: parseInt(newLimit) })
      .then((res) => {
        setSuccessMessage(`✅ Limit updated to ${newLimit}°C for Motor ID ${selectedMotorId}`);
        setTimeout(() => setSuccessMessage(""), 3000);
        window.location.reload(); // Refresh to reflect new limit
      })
      .catch((err) => {
        console.error("Error updating limit:", err);
        alert("❌ Failed to update motor limit!");
      });
  };

  return (
    <div>
      <h2>⚙️ Set Motor Limits</h2>
      
      {/* Success Message */}
      {successMessage && <p style={{ color: "green", fontWeight: "bold" }}>{successMessage}</p>}

      {/* Motor Dropdown */}
      <select value={selectedMotorId} onChange={(e) => setSelectedMotorId(e.target.value)}>
        <option value="">-- Select Motor --</option>
        {motors.map((motor) => (
          <option key={motor.id} value={motor.id}>
            {motor.name} (Current Limit: {motor.temperature_limit}°C)
          </option>
        ))}
      </select>

      {/* New Limit Input */}
      <input 
        type="number" 
        placeholder="New Limit °C" 
        value={newLimit} 
        onChange={(e) => setNewLimit(e.target.value)} 
      />
      
      {/* Update Limit Button */}
      <button onClick={handleSetLimit}>🚀 Update Limit</button>
    </div>
  );
};

export default SetLimits;

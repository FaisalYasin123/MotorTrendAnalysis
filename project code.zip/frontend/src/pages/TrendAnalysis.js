import React, { useEffect, useState } from "react";
import axios from "axios";

const TrendAnalysis = () => {
  const [motors, setMotors] = useState([]);
  const [selectedMotor, setSelectedMotor] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [trendData, setTrendData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/motors/all")
      .then((res) => setMotors(res.data || []))
      .catch((err) => console.error("Error fetching motors:", err));
  }, []);

  const fetchTrendData = () => {
    if (!selectedMotor || !fromDate || !toDate) return alert("Select motor and date range.");
    axios.post("http://localhost:5000/api/trend", { motorId: selectedMotor, fromDate, toDate })
      .then((res) => setTrendData(res.data || []))
      .catch((err) => console.error("Error fetching trend data:", err));
  };

  return (
    <div>
      <h2>Trend Analysis</h2>

      {/* Select Motor */}
      <label>Select Motor:</label>
      <select onChange={(e) => setSelectedMotor(e.target.value)}>
        <option value="">-- Select --</option>
        {motors.map((motor) => (
          <option key={motor.id} value={motor.id}>
            {motor.name} (Section: {motor.section})
          </option>
        ))}
      </select>

      {/* Date Selection */}
      <label>From Date:</label>
      <input type="date" onChange={(e) => setFromDate(e.target.value)} />
      <label>To Date:</label>
      <input type="date" onChange={(e) => setToDate(e.target.value)} />

      {/* Fetch Data */}
      <button onClick={fetchTrendData}>Analyze Trend</button>

      {/* Show Trend Data */}
      {trendData.length === 0 ? (
        <p>No trend data available.</p>
      ) : (
        <ul>
          {trendData.map((data, index) => (
            <li key={index}>
              {data.timestamp}: {data.temperature}°C
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default TrendAnalysis;
